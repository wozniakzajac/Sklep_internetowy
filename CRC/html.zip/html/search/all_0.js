var searchData=
[
  ['klient',['Klient',['../class_klient.html',1,'']]]
];
