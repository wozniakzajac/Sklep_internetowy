var searchData=
[
  ['wlasciciel',['Wlasciciel',['../class_wlasciciel.html',1,'']]]
];
