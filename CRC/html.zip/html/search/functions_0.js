var searchData=
[
  ['przechowuje_5finformacje_5fo_5fdodawanych_5fusuwanych_5fprzez_5fwlasciciela_5fproduktach',['przechowuje_informacje_o_dodawanych_usuwanych_przez_wlasciciela_produktach',['../class_wlasciciel.html#a2818c843f0480c26df3d38a9a5d35b5f',1,'Wlasciciel']]],
  ['przechowuje_5finformacje_5fo_5fdokonanych_5fzakupach',['przechowuje_informacje_o_dokonanych_zakupach',['../class_sklep.html#a7c783df3f95f818f5fdd4390ee9ed7b4',1,'Sklep']]],
  ['przechowuje_5finformacje_5fo_5fprodukcie',['przechowuje_informacje_o_produkcie',['../class_produkt.html#ae6c98acd5c8a424c9edce006e7759ddc',1,'Produkt']]],
  ['przechowuje_5finformacje_5fo_5fzabiegach_5fwykonywanych_5fprzez_5fosobe_5fkupujaca',['przechowuje_informacje_o_zabiegach_wykonywanych_przez_osobe_kupujaca',['../class_klient.html#a7cd3c38106845fb9c6a30282120b31e6',1,'Klient']]]
];
